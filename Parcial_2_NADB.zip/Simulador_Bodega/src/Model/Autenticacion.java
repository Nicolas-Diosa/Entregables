//Hecho por Nicolás Alejandro Diosa
package Model;

import java.io.*;
import java.util.*;

public class Autenticacion {
    Map<String,String> Usuarios = new HashMap<>();//Se crea el hashmap donde se guardará el usuario y la contraseña
    public String r;
    public boolean initses(String usuario,String contraseña){
        boolean estado = false;
        FileReader archivo;
        BufferedReader lector;
        try{
            archivo = new FileReader("PersistenciaDeDatos\\Usuario.txt");
            lector = new BufferedReader(archivo);
            String cadena;
            String usuarioG="";
            String contraseñaG="";
            while ((cadena=lector.readLine())!=null){
                cadena = cadena.replace('{',' ');
                cadena = cadena.replace('}',' ');
                cadena = cadena.replace(',','=');
                String [] campos = cadena.split("=");
                for (int i = 0; i<campos.length; i++){

                    if (i%2==0){usuarioG = campos[i];}
                    else{
                        contraseñaG = campos[i];
                        Usuarios.put(usuarioG.trim(),contraseñaG.trim());
                    }
                }
                if (Usuarios.containsKey(usuario)&&(Usuarios.get(usuario)).equals(contraseña)){
                    estado = true;
                }
                else{
                    r = ("Usuario o contraseña incorrecta");
                    estado = false;
                }
            }
            archivo.close();
        }
        catch(IOException e){
            r = "No se ha podido acceder al archivo";
            estado = false;
        }//Se revisa que si sea cierto que existe un usuario con su contraseña
        return (estado);
    }
    public boolean registroUs(String usuario,String contraseña){
        boolean estado = false;
        boolean caracteresInv = false;
        Usuarios.put(usuario, contraseña);
        FileReader arch;
        BufferedReader lector;
        try{
            arch = new FileReader("PersistenciaDeDatos\\Usuario.txt");
            lector = new BufferedReader(arch);
            String cadena;
            while ((cadena=lector.readLine())!=null){
                if (cadena.contains(usuario)){//Examina si hay un usuario existente
                    estado = true;
                }
                else if(usuario.contains(",")||usuario.contains("{")||usuario.contains("}")||contraseña.contains(",")||contraseña.contains("{")||contraseña.contains("}")){caracteresInv = true;}
            }
        arch.close();
        }
        catch(IOException e){
            r = "No se ha podido acceder al archivo";
        }
        if (estado == true){
            r = "El usuario ingresado ya existe";
            estado =false;
        }
        if (caracteresInv==true){
            r = "Ni el usuario ni la contraseña pueden tener los siguientes caractéres: , } {";
            caracteresInv = false;
        }
        else{
            estado =true;
            try{
                arch = new FileReader("PersistenciaDeDatos\\Usuario.txt");
                lector = new BufferedReader(arch);
                String cadena;
                String usuarioG="";
                String contraseñaG="";
                while ((cadena=lector.readLine())!=null){
                    cadena = cadena.replace('{',' ');
                    cadena = cadena.replace('}',' ');
                    cadena = cadena.replace(',','=');
                    String [] campos = cadena.split("=");
                    for (int i = 0; i<campos.length; i++){

                        if (i%2==0){usuarioG = campos[i];}
                        else{
                            contraseñaG = campos[i];
                            Usuarios.put(usuarioG.trim(),contraseñaG.trim());
                        }
                    }
                }
            arch.close();
            }
            catch(IOException e){
                r = "No se ha podido acceder al archivo";
            }
            FileWriter archivo;
            PrintWriter escritor;
            try{//Se sobrescribe el archivo con el hashmap nuevo de la clave y el usuario
                archivo = new FileWriter("PersistenciaDeDatos\\Usuario.txt");
                escritor = new PrintWriter(archivo);
                escritor.print(Usuarios);
                archivo.close();
                r ="Se ha registrado exitosamente";
            }
            catch(IOException e){
                r = "No se ha podido acceder al archivo";
                estado =false;
            }
        }
        return (estado);
    }
}