//Elaborado por Nicolás Diosa
package Model;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

/**
 *
 * @author Nicolas Diosa
 */
public class gestorDeProductos implements CRUD{
    public String r;
    @Override
    public boolean addProductos(String Nombre, String Precio, String Disponibilidad, String Cantidad){
        String cadena = Nombre+"\t"+Precio+"\t"+Disponibilidad+"\t"+Cantidad;
        String cs;
        FileWriter archivo;
        PrintWriter escritor;
        FileReader arch;
        BufferedReader lector;
        try{
            arch = new FileReader("PersistenciaDeDatos\\Productos.txt");
            lector = new BufferedReader(arch);
            int cont = 1;
            while ((cs=lector.readLine())!=null){
                if (cont != 1){
                    cadena = cadena+"\n"+cs;//Guarda lo que habia anteiormente en el archivo para no perderlo
                }
                cont= cont+1;
            }
            arch.close();
            archivo = new FileWriter("PersistenciaDeDatos\\Productos.txt");
            escritor = new PrintWriter(archivo);
            
            escritor.print("Nombre\tPrecio\tDisp\tCantidad kg\n"+"\n"+cadena);//Guarda el texto en el archivo con los cambios que se efectuaron
            archivo.close();
            r = ("Registro añadido exitosamente");
            return(true);
        }
        catch(IOException e){
            r = ("No se ha podido acceder al archivo");
            return(false);
        }
        
    }
    @Override
    public boolean getProductos(){
        FileReader archivo;
        BufferedReader lector;
        try{
            archivo = new FileReader("PersistenciaDeDatos\\Productos.txt");
            lector = new BufferedReader(archivo);
            String cadena;
            String resul="";
            while ((cadena=lector.readLine())!=null){//Acá compara si todavia hay algun tipo de informacion y si no la hay rompe el ciclo
                resul = resul+"\n"+cadena;//Imprime cada linea que hay en el archivo
            }
            archivo.close();
            r = (resul);
            return (true);
        }
        catch(IOException e){
            r = ("No se ha podido acceder al archivo");
            return (false);
        }
        
    }

    @Override
    public boolean removeProductos() {
        FileWriter archivo;
        PrintWriter escritor;
        try{
            archivo = new FileWriter("PersistenciaDeDatos\\Productos.txt");
            escritor = new PrintWriter(archivo);
             escritor.print("");
             archivo.close();
             r = "Se han eliminado todos los productos exitosamente";
             return(true);
        }
        catch(IOException e){
            r = ("No se ha podido acceder al archivo");
            return(false);
            
        }
    }

    @Override
    public boolean editProductos() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
