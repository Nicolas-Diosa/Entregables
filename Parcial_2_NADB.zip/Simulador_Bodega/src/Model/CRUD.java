//Elaborado por Nicolás Diosa
package Model;
public interface CRUD {
    public abstract boolean addProductos(String Nombre, String Precio, String Disponibilidad, String Cantidad);
    public abstract boolean getProductos();
    public abstract boolean removeProductos();
    public abstract boolean editProductos();
}
