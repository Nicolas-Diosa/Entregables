//Hecho por Nicolás Alejandro Diosa
package modelView;
import View.*;
import java.util.*;
public abstract class Estructura_Bodega {
    static Login l = new Login();
    public static void main(String[] args) {
        
        l.setVisible(true);
    }
    public abstract void InitSesion(String usuario,String contraseña);
    public abstract void RegistroUsuario(String usuario,String contraseña);
    public abstract void mostrarInicio();
    public abstract void mostrarRegistro();
}
