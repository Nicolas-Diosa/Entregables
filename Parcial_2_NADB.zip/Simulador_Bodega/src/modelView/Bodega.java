//Hecho por Nicolás Alejandro Diosa
package modelView;

import java.io.*;
import java.util.*;
import Model.*;
import View.*;

public class Bodega extends Estructura_Bodega {
    gestorDeProductos m = new gestorDeProductos();
    Autenticacion auth = new Autenticacion();
    static FormularioRegistro reg = new FormularioRegistro();
    static Inicio init = new Inicio();
    public static String retorno;
    public static boolean estadoOperacion;
    public static boolean autenticacion;
    public static boolean registro;
    public static String mensaje;
    public void addProductos(String Nombre, String Precio, String Disponibilidad, String Cantidad){
        if (m.addProductos(Nombre, Precio, Disponibilidad, Cantidad)){
            estadoOperacion = true;
        }
        else{
            estadoOperacion = false;
        }
        retorno = m.r;
    }
    public void getProductos(){
        if (m.getProductos()){
            estadoOperacion = true;
        }
        else{
            estadoOperacion = false;
        }
        retorno = m.r;
    }
    @Override
    public void InitSesion(String usuario,String contraseña){
        autenticacion = auth.initses(usuario, contraseña);
        mensaje = auth.r;
    }
    @Override
    public void RegistroUsuario(String usuario,String contraseña){
        registro = auth.registroUs(usuario, contraseña);
        mensaje = auth.r;
    }
    @Override
    public void mostrarInicio(){
        init.setVisible(true);
    }
    @Override
    public void mostrarRegistro(){
        reg.setVisible(true);
    }

    public void quitarProductos() {
        estadoOperacion = m.removeProductos();
        retorno = m.r;
    }
}

