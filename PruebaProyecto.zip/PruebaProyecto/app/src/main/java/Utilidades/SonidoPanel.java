package Utilidades;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.example.pruebaproyecto.R;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Base64;

public class SonidoPanel extends AppCompatActivity {
    Intent cambioPantalla;
    String archivoSalida;
    String ventanaEscogida;
    String sonidoCodificado;
    Spinner sp;
    Button btnGrabarAudio;
    Button btnSubirAudio;
    Button btnPremio;
    Button btnCastigo;
    MediaRecorder grabacion = null;
    public CountDownTimer contador;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sonido_panel);
        btnGrabarAudio = (Button) findViewById(R.id.button2);
        btnSubirAudio = (Button) findViewById(R.id.button2);
        btnPremio = (Button) findViewById(R.id.button);
        btnCastigo = (Button) findViewById(R.id.button3);
        sp = (Spinner) findViewById(R.id.spinnerOp2);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,R.array.opcionesNavegacionSonido, R.layout.spinner_items);
        sp.setAdapter(adapter);

        if (ContextCompat.checkSelfPermission(getApplicationContext(), android.Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(getApplicationContext(), android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(SonidoPanel.this, new String[]{android.Manifest.permission.WRITE_EXTERNAL_STORAGE,android.Manifest.permission.RECORD_AUDIO}, 1000);
        }
        sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int i, long l) {
                ventanaEscogida= (String) parent.getItemAtPosition(i);
                if(ventanaEscogida.equals("Cámara")){
                    cambioPantalla = new Intent(SonidoPanel.this,CamaraPanel.class);
                    startActivity(cambioPantalla);
                }
                else if(ventanaEscogida.equals("Puerta")){
                    cambioPantalla = new Intent(SonidoPanel.this,Compuerta.class);
                    startActivity(cambioPantalla);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
    }
    public void Recorder(View view) throws InterruptedException, IOException {
        if (grabacion == null){
            archivoSalida = getExternalFilesDir(null).getAbsolutePath()+"/aud.mp3";
            grabacion = new MediaRecorder();
            grabacion.setAudioSource(MediaRecorder.AudioSource.MIC);
            grabacion.setOutputFormat(MediaRecorder.OutputFormat.DEFAULT);
            grabacion.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
            grabacion.setOutputFile(archivoSalida);
            try {
                grabacion.prepare();
                grabacion.start();
            }catch(IOException e){
                Toast.makeText(getApplicationContext(),e.toString(),Toast.LENGTH_SHORT).show();
                archivoSalida=e.toString();
                //prueba = (TextView) findViewById(R.id.textView9);
                //prueba.setText(archivoSalida);
            }
            Toast.makeText(getApplicationContext(),"Grabando",Toast.LENGTH_SHORT).show();
            /*accion = new TimerTask() {
                @Override
                public void run() {
                    try {
                        grabacion.stop();
                        grabacion.release();
                        grabacion = null;
                    }catch(Exception e){
                        Toast.makeText(getApplicationContext(),e.toString(),Toast.LENGTH_SHORT).show();
                    }
                    Toast.makeText(getApplicationContext(),"Grabación Finalizada",Toast.LENGTH_SHORT).show();
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                        File archivo = new File(archivoSalida);
                        byte[] buffer = new byte[1024];
                        ByteArrayOutputStream os = new ByteArrayOutputStream();
                        FileInputStream fis = null;
                        try {
                            fis = new FileInputStream(archivo);
                        } catch (FileNotFoundException e) {
                            throw new RuntimeException(e);
                        }
                        int read;
                        while(true){
                            try {
                                if (!((read=fis.read(buffer))!=-1)) break;
                            } catch (IOException e) {
                                throw new RuntimeException(e);
                            }
                            os.write(buffer,0,read);
                        }
                        try {
                            fis.close();
                        } catch (IOException e) {
                            throw new RuntimeException(e);
                        }
                        try {
                            os.close();
                        } catch (IOException e) {
                            throw new RuntimeException(e);
                        }
                        byte[] bytes = os.toByteArray();
                        sonidoCodificado = Base64.getEncoder().encodeToString(bytes);
                        subirAudio(sonidoCodificado);
                        cancel();
                    }
                }
            };
            tiempoGrabacion = new Timer();
            tiempoGrabacion.scheduleAtFixedRate(accion,0,5000);*/
        }
        else if(grabacion!=null){
            try {
                grabacion.stop();
                grabacion.release();
                grabacion = null;
            }catch(Exception e){
                Toast.makeText(getApplicationContext(),e.toString(),Toast.LENGTH_SHORT).show();
            }
            Toast.makeText(getApplicationContext(),"Grabación Finalizada",Toast.LENGTH_SHORT).show();
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                File archivo = new File(archivoSalida);
                byte[] buffer = new byte[1024];
                ByteArrayOutputStream os = new ByteArrayOutputStream();
                FileInputStream fis = new FileInputStream(archivo);
                int read;
                while((read=fis.read(buffer))!=-1){
                    os.write(buffer,0,read);
                }
                fis.close();
                os.close();
                byte[] bytes = os.toByteArray();
                sonidoCodificado = Base64.getEncoder().encodeToString(bytes);
                subirAudio(sonidoCodificado);
            }
        }
    }
    public void subirAudio(String sonido){
        FirebaseDatabase db = FirebaseDatabase.getInstance();
        DatabaseReference ref = db.getReference().child("Sonido");
        ref.child("Audio").setValue(sonido);
    }
    public void reproducirAudio(View view){
        MediaPlayer reproductor = new MediaPlayer();
        try {
            reproductor.setDataSource(archivoSalida);
            reproductor.prepare();

        }catch (IOException e) {

        }
        reproductor.start();
        Toast.makeText(getApplicationContext(),"Reproduciendo Grabación",Toast.LENGTH_SHORT).show();

    }
    public void onClick(View v){
        if(v.getId()==R.id.button){
            FirebaseDatabase db = FirebaseDatabase.getInstance();
            DatabaseReference ref = db.getReference().child("Sonido");
            ref.child("Tipo").setValue("Castigo");
            contador = new CountDownTimer(6000,1000) {
                @Override
                public void onTick(long l) {

                }

                @Override
                public void onFinish() {
                    ref.child("Tipo").setValue("");;
                }
            }.start();
        }
        else if (v.getId()==R.id.button3){
            FirebaseDatabase db = FirebaseDatabase.getInstance();
            DatabaseReference ref = db.getReference().child("Sonido");
            ref.child("Tipo").setValue("Premio");
            contador = new CountDownTimer(6000,1000) {
                @Override
                public void onTick(long l) {

                }

                @Override
                public void onFinish() {
                    ref.child("Tipo").setValue("");;
                }
            }.start();
        }
    }
}