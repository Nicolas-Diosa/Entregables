package Utilidades;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.pruebaproyecto.R;

public class InicioSesion extends AppCompatActivity implements View.OnClickListener{

    EditText campoUsuario,campoContraseña;
    ConexionSQLite conn = new ConexionSQLite(this, "bd_usuarios", null, 1);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.inicio_sesion);
        campoUsuario = (EditText) findViewById(R.id.CampoUsuario);
        campoContraseña = (EditText) findViewById(R.id.campoContraseña);
    }
    Intent cambio = null;
    @Override
    public void onClick(View v) {
        int id = v.getId();
        if (id == R.id.botonReg) {
            cambio = new Intent(InicioSesion.this, RegistroUsuario.class);
            startActivity(cambio);
        } else if (id == R.id.botonIni) {
            if (ValidarUsuario()){
                cambio = new Intent(InicioSesion.this, Home.class);
                startActivity(cambio);
            }
        }
    }
    private boolean ValidarUsuario(){
        SQLiteDatabase db = conn.getReadableDatabase();
        String[] parametros = {campoUsuario.getText().toString()};
        String[] campos = {Utilidades.CampoUsuario,Utilidades.CampoContraseña};
        boolean estado = false;

        try {
            Cursor cursor = db.query(Utilidades.Nombre,campos,Utilidades.CampoUsuario+"=?",parametros,null,null,null);
            cursor.moveToFirst();
            if (cursor.getString(0).equals(campoUsuario.getText().toString())){
                if (cursor.getString(1).equals(campoContraseña.getText().toString())){
                    Toast.makeText(getApplicationContext(), "Bienvenido", Toast.LENGTH_LONG).show();
                    estado = true;}
                else {
                    Toast.makeText(getApplicationContext(), "El usuario o contraseña son incorrectos", Toast.LENGTH_LONG).show();
                    estado = false;
                }
            }
            cursor.close();
        }catch(Exception e){
            Toast.makeText(getApplicationContext(), "Ha habido un problema", Toast.LENGTH_LONG).show();

        }
        return (estado);
    }
}