package Utilidades;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import com.example.pruebaproyecto.R;

public class Home extends AppCompatActivity{
    String CHANNEL_ID = "channelId";
    String ChannelName = "Canal1";

    Intent cambio = null;
    Intent paraServicio;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home);
    }

    public void onClick(View view) {
        cambio = new Intent(Home.this, CamaraPanel.class);
        startActivity(cambio);
        startService(new Intent(getApplicationContext(),ServicioNotificaciones.class)); 
        crearCanal();
    }

    public void crearCanal() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            mostrarNotificacion();
        } else {
            mostrarNuevaNotificacion();
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    private void mostrarNotificacion() {
        NotificationChannel canal = new NotificationChannel(CHANNEL_ID, ChannelName, NotificationManager.IMPORTANCE_DEFAULT);
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        manager.createNotificationChannel(canal);
        mostrarNuevaNotificacion();
    }

    private void mostrarNuevaNotificacion() {
        NotificationCompat.Builder builder = new NotificationCompat.Builder(getApplicationContext(), CHANNEL_ID).setSmallIcon(R.drawable.gorrion_sin_fondo).setContentTitle("No te olvides de tu gorrión").setContentText("Recuerda reabastecer a tu gorrión de comida y agua y cambiar su bandejita de residuos.").setPriority(NotificationCompat.PRIORITY_DEFAULT);
        NotificationManagerCompat managerCompat = NotificationManagerCompat.from(getApplicationContext());
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {

            return;
        }
        managerCompat.notify(1, builder.build());
    }
}