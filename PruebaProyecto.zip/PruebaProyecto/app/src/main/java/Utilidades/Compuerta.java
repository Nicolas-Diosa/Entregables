package Utilidades;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;

import com.example.pruebaproyecto.R;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Compuerta extends AppCompatActivity {
    Spinner spinner;
    String ventanaEscogida;
    Intent cambioPantalla;
    String valoAnterior=null;
    String valorActual;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_compuerta);
        spinner = (Spinner) findViewById(R.id.spinnerOp3);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,R.array.opcionesNavegacionPuerta, R.layout.spinner_items);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int i, long l) {
                ventanaEscogida= (String) parent.getItemAtPosition(i);
                if(ventanaEscogida.equals("Cámara")){
                    cambioPantalla = new Intent(Compuerta.this,CamaraPanel.class);
                    startActivity(cambioPantalla);
                }
                else if(ventanaEscogida.equals("Sonido")){
                    cambioPantalla = new Intent(Compuerta.this,SonidoPanel.class);
                    startActivity(cambioPantalla);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

    }

    public void onClick(View view) {
        if (view.getId() == R.id.imageButton){
            valorActual = "Abierto";
            if(valorActual.equals(valoAnterior) == false){
                FirebaseDatabase db = FirebaseDatabase.getInstance();
                DatabaseReference ref = db.getReference().child("Puerta");
                ref.child("Estado").setValue(valorActual);
                valoAnterior=valorActual;
            }
            else{

            }
        }
        else if(view.getId() == R.id.imageButton2){
            valorActual = "Cerrado";
            if(valorActual.equals(valoAnterior) == false){
                FirebaseDatabase db = FirebaseDatabase.getInstance();
                DatabaseReference ref = db.getReference().child("Puerta");
                ref.child("Estado").setValue(valorActual);
                valoAnterior=valorActual;
            }
            else{

            }
        }

    }
}