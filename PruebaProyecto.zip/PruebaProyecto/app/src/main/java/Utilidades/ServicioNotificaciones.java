package Utilidades;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.CountDownTimer;
import android.os.IBinder;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import com.example.pruebaproyecto.R;

public class ServicioNotificaciones extends Service {
    String CHANNEL_ID = "channelId";
    String ChannelName = "Canal1";
    public CountDownTimer contador;
    public void onCreate(){
        super.onCreate();
        contador = new CountDownTimer(6000,1000) {
            @Override
            public void onTick(long l) {

            }

            @Override
            public void onFinish() {
                crearCanal();
            }
        }.start();

    }
    public void crearCanal() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            mostrarNotificacion();
        } else {
            mostrarNuevaNotificacion();
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    private void mostrarNotificacion() {
        NotificationChannel canal = new NotificationChannel(CHANNEL_ID, ChannelName, NotificationManager.IMPORTANCE_DEFAULT);
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        manager.createNotificationChannel(canal);
        mostrarNuevaNotificacion();
    }

    private void mostrarNuevaNotificacion() {
        NotificationCompat.Builder builder = new NotificationCompat.Builder(getApplicationContext(), CHANNEL_ID).setSmallIcon(R.drawable.gorrion_sin_fondo).setContentTitle("Notificacion con timer y actividad").setContentText("Recuerda reabastecer a tu gorrión de comida y agua y cambiar su bandejita de residuos.").setPriority(NotificationCompat.PRIORITY_DEFAULT);
        NotificationManagerCompat managerCompat = NotificationManagerCompat.from(getApplicationContext());
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {

            return;
        }
        managerCompat.notify(2, builder.build());
    }
    public void onDestroy(){
        super.onDestroy();
    }
    public int onStartCommand(Intent intent, int flags, int startId){
        return START_STICKY;
    }
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
