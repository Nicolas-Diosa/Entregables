package Utilidades;

public class Utilidades {
    //Constantes
    public static final String Nombre = "usuarios";
    public static final String CampoUsuario = "usuario";
    public static final String CampoContraseña = "contraseña";
    public static final String cTabla="CREATE TABLE "+Nombre+" ("+CampoUsuario+" TEXT, "+CampoContraseña+" TEXT)";

}
