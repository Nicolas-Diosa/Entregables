package Utilidades;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.pruebaproyecto.R;

public class RegistroUsuario extends AppCompatActivity {
    ConexionSQLite conn = new ConexionSQLite(this, "bd_usuarios", null, 1);
    EditText campoUsuario,campoContraseña,campoContraseña2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.registro_usuario);

        campoContraseña = (EditText) findViewById(R.id.RegistroContraseña);
        campoUsuario = (EditText) findViewById(R.id.RegistroUsuario);
        campoContraseña2 = (EditText) findViewById(R.id.ConfirmacionContraseña);

    }

    public void onClick(View view) {
        registrarUsuarios();
    }
    private void registrarUsuarios(){
        if(consultarUsuarioExistente()) {
            if ((campoContraseña.getText().toString()).equals(campoContraseña2.getText().toString())) {
                SQLiteDatabase db = conn.getWritableDatabase();
                ContentValues values = new ContentValues();
                values.put(Utilidades.CampoUsuario, campoUsuario.getText().toString());
                values.put(Utilidades.CampoContraseña, campoContraseña.getText().toString());

                long setenciaSql = db.insert(Utilidades.Nombre, Utilidades.CampoUsuario, values);

                Toast.makeText(getApplicationContext(), "Se ha registrado existosamente, Id Registro: " + setenciaSql, Toast.LENGTH_LONG).show();
                Intent cambio = new Intent(RegistroUsuario.this, InicioSesion.class);
                startActivity(cambio);
            } else {
                Toast.makeText(getApplicationContext(), "La contraseña de confirmacion debe ser la misma que la del primer campo", Toast.LENGTH_LONG).show();
            }
        }
        else {
            Toast.makeText(getApplicationContext(), "Este usuario ya está en uso", Toast.LENGTH_LONG).show();
        }
    }
    private boolean consultarUsuarioExistente(){
        SQLiteDatabase db = conn.getReadableDatabase();
        String[] parametros = {campoUsuario.getText().toString()};
        String[] campos = {Utilidades.CampoUsuario};
        boolean estado = false;

        try {
            Cursor cursor = db.query(Utilidades.Nombre,campos,Utilidades.CampoUsuario+"=?",parametros,null,null,null);
            cursor.moveToFirst();
            if (cursor.getString(0).equals(campoUsuario.getText().toString())){
                estado = false;
            }
            cursor.close();
        }catch(Exception e){
            estado = true;
        }
        return (estado);
    }
}